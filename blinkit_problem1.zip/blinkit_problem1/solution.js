document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    document.getElementById('signupMessage').textContent = "Sign up successful.";
});
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var loginUsername = document.getElementById('loginUsername').value;
    var loginPassword = document.getElementById('loginPassword').value;
    document.getElementById('loginMessage').textContent = "Login successful.";
});
function uploadImage() {
    var imageFile = document.getElementById('imageFile').files[0];
     document.getElementById('uploadMessage').textContent = "Image uploaded successfully.";
}
